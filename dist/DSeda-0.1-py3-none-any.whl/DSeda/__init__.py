# -*- coding: utf-8 -*-
"""
Created on Wed May 18 16:51:54 2022

@author: crist
"""

def add_number(a,b):
	return a+b