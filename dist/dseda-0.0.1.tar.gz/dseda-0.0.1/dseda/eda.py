# -*- coding: utf-8 -*-
"""
Created on Thu May 19 09:47:02 2022

@author: crist
"""

def add_one(number):
    return number + 1
