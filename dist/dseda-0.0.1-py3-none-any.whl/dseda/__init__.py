# -*- coding: utf-8 -*-
"""
Created on Thu May 19 09:46:50 2022

@author: crist
"""

from .eda import add_one